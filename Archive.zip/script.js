const dishes = [
    {
        image: "images/dish-1.png",
        title: "Тигровые креветки",
        price: "750 ₽"
    },
    {
        image: "images/dish-2.png",
        title: "Корюшка жареная в панировке",
        price: "620 ₽"
    },
    {
        image: "images/dish-3.png",
        title: "Черноморская барабулька, жареная на сковородке",
        price: "810 ₽"
    }
];

const gallery = document.querySelector(".gallery");

let current = 0;

const items = [];

/* Создаём ВСЕ карточки один раз */
dishes.forEach((dish) => {
    const card = document.createElement("div");

    card.classList.add("gallery-item");

    card.innerHTML = `
        <img src="${dish.image}" alt="">

        <div class="dish-info">
            <p class="dish-description">${dish.title}</p>
            <hr>
            <p class="dish-description">${dish.price}</p>
        </div>
    `;

    gallery.appendChild(card);

    items.push(card);
});

/* Обновляем позиции */
function updateGallery() {

    items.forEach((item) => {
        item.classList.remove(
            "left",
            "center",
            "right",
            "hidden"
        );
    });

    const left =
        (current - 1 + dishes.length)
        % dishes.length;

    const right =
        (current + 1)
        % dishes.length;

    items[left].classList.add("left");

    items[current].classList.add("center");

    items[right].classList.add("right");

    /* Остальные скрываем */
    items.forEach((item, index) => {

        if (
            index !== left &&
            index !== current &&
            index !== right
        ) {
            item.classList.add("hidden");
        }
    });
}

updateGallery();

/* Кнопка вправо */
document
    .querySelector(".next")
    .addEventListener("click", () => {

        current =
            (current + 1)
            % dishes.length;

        updateGallery();
    });

/* Кнопка влево */
document
    .querySelector(".prev")
    .addEventListener("click", () => {

        current =
            (current - 1 + dishes.length)
            % dishes.length;

        updateGallery();
    });